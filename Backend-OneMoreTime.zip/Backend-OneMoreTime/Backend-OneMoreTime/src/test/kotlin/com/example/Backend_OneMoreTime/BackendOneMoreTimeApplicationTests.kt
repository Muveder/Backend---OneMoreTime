package com.example.Backend_OneMoreTime

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BackendOneMoreTimeApplicationTests {

	@Test
	fun contextLoads() {
	}

}
