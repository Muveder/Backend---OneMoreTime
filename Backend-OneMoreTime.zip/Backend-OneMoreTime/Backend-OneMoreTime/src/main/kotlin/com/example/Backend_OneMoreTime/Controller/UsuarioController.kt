package com.example.Backend_OneMoreTime.Controller // 'C' mayúscula

import com.example.Backend_OneMoreTime.Controller.dto.LoginRequest
import com.example.Backend_OneMoreTime.Controller.dto.RegisterRequest
import com.example.Backend_OneMoreTime.Controller.dto.UpdateRoleRequest
import com.example.Backend_OneMoreTime.model.Usuario
import com.example.Backend_OneMoreTime.Repository.UsuarioRepository // 'R' mayúscula
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

@RestController
@RequestMapping("/api/usuarios")
class UsuarioController(private val usuarioRepository: UsuarioRepository) {

    @PostMapping("/register")
    fun register(@RequestBody request: RegisterRequest): ResponseEntity<Usuario> {
        if (usuarioRepository.findByCorreo(request.correo) != null) {
            throw ResponseStatusException(HttpStatus.BAD_REQUEST, "El correo ya está en uso.")
        }
        val nuevoUsuario = Usuario(
            nombre = request.nombre,
            correo = request.correo,
            clave = request.clave,
            direccion = request.direccion
        )
        val usuarioGuardado = usuarioRepository.save(nuevoUsuario)
        return ResponseEntity(usuarioGuardado, HttpStatus.CREATED)
    }

    @PostMapping("/login")
    fun login(@RequestBody request: LoginRequest): Usuario {
        // --- CORRECCIÓN DE LÓGICA DE LOGIN ---
        // El campo 'request.correo' en realidad contiene la credencial (puede ser correo o nombre).

        // 1. Intenta buscar por correo electrónico primero.
        var usuario = usuarioRepository.findByCorreo(request.correo)

        // 2. Si no lo encuentra por correo, intenta buscar por nombre de usuario.
        if (usuario == null) {
            usuario = usuarioRepository.findByNombre(request.correo)
        }

        // 3. Si después de ambos intentos el usuario sigue siendo nulo, las credenciales son incorrectas.
        if (usuario == null) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, "Credenciales incorrectas.")
        }

        // 4. Comprueba si la clave es correcta.
        if (usuario.clave != request.clave) {
            throw ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales incorrectas.")
        }

        // 5. Si todo es correcto, devuelve los datos del usuario.
        return usuario
    }

    @GetMapping
    fun getAllUsers(): List<Usuario> {
        return usuarioRepository.findAll()
    }

    @PutMapping("/{id}/role")
    fun updateUserRole(@PathVariable id: Long, @RequestBody request: UpdateRoleRequest): Usuario {
        val usuario = usuarioRepository.findById(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado.") }

        val updatedUsuario = usuario.copy(role = request.role)
        return usuarioRepository.save(updatedUsuario)
    }
}