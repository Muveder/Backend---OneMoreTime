package com.example.Backend_OneMoreTime.model

import jakarta.persistence.Entity
import jakarta.persistence.EnumType
import jakarta.persistence.Enumerated
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.Table
import java.time.Instant

@Entity
@Table(name = "usuarios")
data class Usuario(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    val nombre: String,
    val correo: String,
    val clave: String,
    val direccion: String,
    val karma: Int = 0,
    val createdAt: Instant = Instant.now(),
    val avatarUrl: String? = null,
    val nombreReal: String? = null,
    val cumpleanos: Long? = null,

    @Enumerated(EnumType.STRING)
    val role: UserRole = UserRole.USER
)