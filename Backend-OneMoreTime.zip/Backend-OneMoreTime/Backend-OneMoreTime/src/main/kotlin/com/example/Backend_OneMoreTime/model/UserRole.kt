package com.example.Backend_OneMoreTime.model // Asegúrate de que el paquete sea el correcto

enum class UserRole {
    ADMIN,MODERATOR,
    USER,
    GUEST
}
