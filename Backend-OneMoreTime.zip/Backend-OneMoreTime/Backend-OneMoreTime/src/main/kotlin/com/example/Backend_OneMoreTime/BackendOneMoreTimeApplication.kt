package com.example.Backend_OneMoreTime

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class BackendOneMoreTimeApplication

fun main(args: Array<String>) {
	runApplication<BackendOneMoreTimeApplication>(*args)
}
