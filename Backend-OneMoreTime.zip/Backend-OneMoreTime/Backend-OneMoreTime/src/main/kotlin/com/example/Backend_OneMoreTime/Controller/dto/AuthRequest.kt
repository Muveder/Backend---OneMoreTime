package com.example.Backend_OneMoreTime.Controller.dto // 'C' mayúscula

data class RegisterRequest(
    val nombre: String,
    val correo: String,
    val clave: String,
    val direccion: String
)

data class LoginRequest(
    val correo: String,
    val clave: String
)