package com.example.Backend_OneMoreTime.Controller.dto // 'C' mayúscula

import com.example.Backend_OneMoreTime.model.UserRole

data class UpdateRoleRequest(
    val role: UserRole
)