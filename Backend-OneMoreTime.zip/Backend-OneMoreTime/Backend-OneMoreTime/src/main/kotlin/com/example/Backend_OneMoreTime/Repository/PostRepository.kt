package com.example.Backend_OneMoreTime.Repository // <-- LÍNEA CORREGIDA

import com.example.Backend_OneMoreTime.model.Post // <-- LÍNEA CORREGIDA
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface PostRepository : JpaRepository<Post, Long> {}