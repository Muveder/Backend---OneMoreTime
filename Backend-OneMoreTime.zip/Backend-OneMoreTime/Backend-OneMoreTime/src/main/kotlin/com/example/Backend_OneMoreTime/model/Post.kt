package com.example.Backend_OneMoreTime.model // O como se llame tu paquete

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import java.time.Instant

@Entity
data class Post(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val title: String,
    val community: String,
    val author: String,
    val content: String?,
    val score: Int,
    val comments: Int,
    val rating: Float,
    val imageUrl: String?
) {
    // Movemos createdAt aquí. Ya no es parte del constructor.
    // Se inicializará automáticamente cuando se cree un objeto Post.
    val createdAt: Instant = Instant.now()
}