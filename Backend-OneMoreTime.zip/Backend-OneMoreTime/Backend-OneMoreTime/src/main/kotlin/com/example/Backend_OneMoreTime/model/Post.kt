package com.example.Backend_OneMoreTime.model

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import java.time.Instant

@Entity
data class Post(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,
    val title: String,
    val community: String,

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    val author: Usuario,

    val content: String? = null,
    val rating: Float = 0.0f,
    val score: Int = 0,
    val comments: Int = 0,
    val imageUrl: String? = null,
    val createdAt: Instant = Instant.now()
)