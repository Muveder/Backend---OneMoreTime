package com.example.Backend_OneMoreTime.controller.dto

// Datos que la app enviará para crear un nuevo post
data class CreatePostRequest(
    val title: String,
    val community: String,
    val authorId: Long, // <-- CAMBIO CLAVE: Enviamos el ID del autor
    val content: String?,
    val rating: Float,
    val imageUrl: String?
)