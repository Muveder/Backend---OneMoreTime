package com.example.Backend_OneMoreTime.Controller // 'C' mayúscula

import com.example.Backend_OneMoreTime.controller.dto.CreatePostRequest
import com.example.Backend_OneMoreTime.model.Post
import com.example.Backend_OneMoreTime.Repository.PostRepository   // 'R' mayúscula
import com.example.Backend_OneMoreTime.Repository.UsuarioRepository // 'R' mayúscula
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

@RestController
@RequestMapping("/api/posts")
class PostController(
    private val postRepository: PostRepository,
    private val usuarioRepository: UsuarioRepository
) {

    @GetMapping
    fun getAllPosts(pageable: Pageable): Page<Post> {
        return postRepository.findAll(pageable)
    }

    @PostMapping
    fun createPost(@RequestBody request: CreatePostRequest): ResponseEntity<Post> {
        val author = usuarioRepository.findById(request.authorId)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario autor no encontrado.") }

        val newPost = Post(
            title = request.title,
            community = request.community,
            author = author,
            content = request.content,
            rating = request.rating,
            imageUrl = request.imageUrl
        )

        val savedPost = postRepository.save(newPost)
        return ResponseEntity(savedPost, HttpStatus.CREATED)
    }

    @GetMapping("/{id}")
    fun getPostById(@PathVariable id: Long): Post {
        return postRepository.findById(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id") }
    }

    @PutMapping("/{id}")
    fun updatePost(@PathVariable id: Long, @RequestBody updatedPostData: CreatePostRequest): Post {
        val existingPost = postRepository.findById(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id") }

        val updatedPost = existingPost.copy(
            title = updatedPostData.title,
            community = updatedPostData.community,
            content = updatedPostData.content,
            rating = updatedPostData.rating,
            imageUrl = updatedPostData.imageUrl
        )
        return postRepository.save(updatedPost)
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    fun deletePost(@PathVariable id: Long) {
        if (!postRepository.existsById(id)) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id")
        }
        postRepository.deleteById(id)
    }
}