package com.example.Backend_OneMoreTime.Controller //
import com.example.Backend_OneMoreTime.model.Post
import com.example.Backend_OneMoreTime.Repository.PostRepository //
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.server.ResponseStatusException

@RestController
@RequestMapping("/api/posts")
class PostController(private val postRepository: PostRepository) {

    // --- READ (Todos los posts, paginado) ---
    @GetMapping
    fun getAllPosts(pageable: Pageable): Page<Post> {
        return postRepository.findAll(pageable)
    }

    // --- CREATE (Crear un nuevo post) ---
    @PostMapping
    fun createPost(@RequestBody post: Post): ResponseEntity<Post> {
        val savedPost = postRepository.save(post)
        return ResponseEntity(savedPost, HttpStatus.CREATED)
    }

    // --- READ (Leer un solo post por su ID) ---
    @GetMapping("/{id}")
    fun getPostById(@PathVariable id: Long): Post {
        return postRepository.findById(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id") }
    }

    // --- UPDATE (Actualizar un post existente) ---
    @PutMapping("/{id}")
    fun updatePost(@PathVariable id: Long, @RequestBody newPostData: Post): Post {
        val existingPost = postRepository.findById(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id") }

        val updatedPost = existingPost.copy(
            title = newPostData.title,
            community = newPostData.community,
            content = newPostData.content,
            rating = newPostData.rating,
            imageUrl = newPostData.imageUrl
        )
        return postRepository.save(updatedPost)
    }

    // --- DELETE (Borrar un post) ---
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    fun deletePost(@PathVariable id: Long) {
        if (!postRepository.existsById(id)) {
            throw ResponseStatusException(HttpStatus.NOT_FOUND, "Post no encontrado con id $id")
        }
        postRepository.deleteById(id)
    }
}