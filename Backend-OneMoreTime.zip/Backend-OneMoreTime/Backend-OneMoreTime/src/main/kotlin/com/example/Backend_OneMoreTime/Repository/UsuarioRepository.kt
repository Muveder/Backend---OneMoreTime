package com.example.Backend_OneMoreTime.Repository // 'R' mayúscula

import com.example.Backend_OneMoreTime.model.Usuario
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UsuarioRepository : JpaRepository<Usuario, Long> {
    fun findByNombre(nombre: String): Usuario?
    fun findByCorreo(correo: String): Usuario?
}